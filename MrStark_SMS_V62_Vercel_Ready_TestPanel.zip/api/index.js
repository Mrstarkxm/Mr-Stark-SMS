// Vercel entrypoint: reuse the existing MrStark Node HTTP server.
module.exports = require('../server');
